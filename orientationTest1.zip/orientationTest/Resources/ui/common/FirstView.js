//FirstView Component Constructor
function FirstView() {
	//create object instance, a parasitic subclass of Observable
	var self = Ti.UI.createView();

	//label using localization-ready strings from <app dir>/i18n/en/strings.xml
	var label = Ti.UI.createLabel({
		color:'#000000',
		text:String.format(L('welcome'),'Titanium'),
		height:'auto',
		width:'auto'
	});
	self.add(label);

	//Add behavior for UI
	label.addEventListener('click', function(e) {
		alert(e.source.text);
	});
	
	var button = Ti.UI.createButton({
		height:44,
		width:'90%',
		color : 'white',
		title:L('Open a New Window in Landscape Mode'),
		top:200,
		backgroundColor : '#ff7c00'
	});
	
	button.addEventListener('click', function() {
		var newWin = Ti.UI.createWindow({
			title: L('newWindow'),
			backgroundColor: 'white'
		});
		
		var button = Ti.UI.createButton({
			height:44,
			width:'80%',
			color : 'white',
			title:L('landscape mode'),
			top:200,
			backgroundColor : '#ff7c00'
		});
		
		button.addEventListener('click', function() {
			newWin.close();
		});
	
		newWin.add(button);
		newWin.orientationModes =[Ti.UI.LANDSCAPE_LEFT, Ti.UI.LANDSCAPE_RIGHT];		
		newWin.open();
	});
	
	self.add(button);

	return self;
}

module.exports = FirstView;
